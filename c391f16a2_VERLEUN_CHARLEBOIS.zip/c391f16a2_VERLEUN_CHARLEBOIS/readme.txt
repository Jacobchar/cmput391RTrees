
CMPUT 391 Assignment #2

Completed by:
	Robin Verleun
	Jacob Charlebois


To compile the code:
	Navigate to the assignment submission folder.

	Enter the commands:
					cd src/
					make


The project requires the use of the sqlite3.c amalgamation in order to run.

Command Line Arguments:
	
		q4: x1(float), y1(float), x2(float), y2(float), class(string)
		q5: length(int)
		q7: x(float), y(float)
		q8:	x(float), y(float), k_points(int)


Exchanged ideas with Greg Antonious, Steve Boddezz, and Scott Wowk.
